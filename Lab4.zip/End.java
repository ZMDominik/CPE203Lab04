public class End {

    private String session;

    public End (String session_id){
        this.session = session_id;
    }
}
